#include "thread.h"

/***
 *
 * function for int data

void print_node_int(struct Node* ptr){
	printf("%d->", ptr->data.num);
}

void free_data_int(union Data data){
}

int comp_int(union Data a, union Data b){
	if(a.num == b.num){return 0;}
	else if(a.num > b.num){return 1;}
	else{return -1;}
}
 */
